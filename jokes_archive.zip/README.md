# set5 Data

## To Import Jokes, just head on over to /import

Hello Set5 Team!

In this repo, you'll find my Jokes Project, partially developed.

I went with working via Symfony, which may have been to my detriment.

I love the framework, but I was spending a good amount of time syntax-searching, and fixing a few errors due to being a bit more unfamiliar with the framework in general.

I hope you can appreciate my work, and I look forward to completing this project anyways.

It was a great way to get much more comfortable with Symfony than I was in the past.

Much appreciation for the opportunity, and I hope to talk to you soon.

Cheers,
Lance
